#include <stdio.h>
int main()
{
	//helloworld1 test.
   // printf() displays the string inside quotation
   printf("Hello, World! with \n");



   printf("Hello, World! without");
   return 0;


}


